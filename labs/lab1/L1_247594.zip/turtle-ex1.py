# Course: IT1 1120
# Lab 1
# Nangfack, Pavel
# 300247594

import turtle

s = turtle.Screen()
t = turtle.Turtle()

# Place your code after this line
t.speed(0)
t.pd()

t.fd(200)
t.bk(200)
t.right(45)

t.fd(200)
t.bk(200)
t.right(45)

t.fd(200)
t.bk(200)
t.right(45)

t.fd(200)
t.bk(200)
t.right(45)

t.fd(200)
t.bk(200)
t.right(45)

t.fd(200)
t.bk(200)
t.right(45)

t.fd(200)
t.bk(200)
t.right(45)

t.fd(200)
t.bk(200)
t.right(45)

t.setheading(90)
t.goto(10, 0)
t.circle(10)

t.goto(50, 0)
t.circle(50)

t.goto(75, 0)
t.circle(75)

t.goto(100, 0)
t.circle(100)
